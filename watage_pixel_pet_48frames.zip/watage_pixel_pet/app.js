(()=>{
 'use strict';
 const clips=window.WATAGE_FRAMES, stage=document.getElementById('stage'), pet=document.getElementById('pet'), status=document.getElementById('label');
 const buttons=[...document.querySelectorAll('[data-action]')], auto=document.getElementById('autoplay');
 const names={idle:'おすわり',look:'キョロキョロ',walk:'ウロウロ',groom:'毛づくろい',curl:'丸まる',sleep:'すやすや',stretch:'起床・伸び',grabbed:'液体I字',thrown:'投げられる',land:'着地・復帰'};
 const random=(a,b)=>a+Math.random()*(b-a), clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
 let mode='idle',idx=0,elapsed=0,total=0,limit=6500,held=false,velocityX=0,velocityY=0,face=1,points=[];
 let x=stage.clientWidth/2-pet.offsetWidth/2,y=15,last=performance.now();
 function setMode(next){mode=next;idx=0;elapsed=0;total=0;status.textContent=names[next];
  buttons.forEach(b=>b.classList.toggle('active',b.dataset.action===next));
  limit=({idle:()=>random(4000,8500),walk:()=>random(3000,8000),look:()=>random(2200,5000),groom:()=>random(2500,5000),sleep:()=>random(30000,90000)})[next]?.()||Infinity;
  if(next==='land') {velocityX=0;velocityY=0;y=15;}
  render();
 }
 function render(){const list=clips[mode];let f=list[idx]||list[0];pet.style.backgroundImage=`url("${f.src}")`;
  pet.style.left=`${x}px`;pet.style.bottom=`${y}px`;
  pet.style.transform=mode==='walk'&&face>0?'scaleX(-1)':'scaleX(1)';
 }
 function nextNatural(){if(!auto.checked){setMode('idle');return;}
  if(mode==='curl') return setMode('sleep');if(mode==='sleep')return setMode('stretch');if(mode==='stretch')return setMode('idle');
  if(mode==='look'||mode==='groom'||mode==='walk'||mode==='land')return setMode('idle');
  const r=Math.random(); setMode(r<.34?'walk':r<.57?'look':r<.76?'groom':'curl');
 }
 function advance(dt){let list=clips[mode];elapsed+=dt;total+=dt;
  while(elapsed>=list[idx].ms){elapsed-=list[idx].ms;idx++;
   if(mode==='grabbed'&&idx>=list.length){idx=2;}
   else if(idx>=list.length){idx=0;if(['curl','stretch','land'].includes(mode)){nextNatural();return;}}
  }
  if(mode==='walk'&&!held){x+=face*65*dt/1000;const max=Math.max(0,stage.clientWidth-pet.offsetWidth);if(x<5){x=5;face=1;}if(x>max-5){x=max-5;face=-1;}}
  if(mode==='thrown'&&!held){let sec=dt/1000;x+=velocityX*sec;y+=velocityY*sec;velocityY-=860*sec;velocityX*=Math.pow(.3,sec);
   if(x<0){x=0;velocityX=-velocityX*.35;}if(x>stage.clientWidth-pet.offsetWidth){x=stage.clientWidth-pet.offsetWidth;velocityX=-velocityX*.35;}
   if(y<=15){y=15;setMode('land');return;}
  }
  if(!held && total>=limit && ['idle','walk','look','groom','sleep'].includes(mode))nextNatural();
  render();
 }
 function tick(t){let dt=Math.min(60,Math.max(0,t-last));last=t;advance(dt);requestAnimationFrame(tick);}requestAnimationFrame(tick);
 pet.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();held=true;points=[];pet.setPointerCapture(e.pointerId);pet.classList.add('dragging');setMode('grabbed');drag(e);});
 function drag(e){if(!held)return;const r=stage.getBoundingClientRect();x=clamp(e.clientX-r.left-pet.offsetWidth/2,0,stage.clientWidth-pet.offsetWidth);
  y=clamp(r.bottom-e.clientY-pet.offsetHeight/2,15,stage.clientHeight-pet.offsetHeight+12);
  points.push({x,y,t:performance.now()});while(points.length>9)points.shift();render();}
 pet.addEventListener('pointermove',drag);
 function release(){if(!held)return;held=false;pet.classList.remove('dragging');let lastPoint=points.at(-1),firstPoint=points[0];
  if(lastPoint&&firstPoint){let elapsedMs=Math.max(30,lastPoint.t-firstPoint.t);velocityX=clamp((lastPoint.x-firstPoint.x)/elapsedMs*1000,-520,520);velocityY=clamp((lastPoint.y-firstPoint.y)/elapsedMs*1000,-600,650);}
  else {velocityX=0;velocityY=0;}
  if(y>30||Math.abs(velocityX)>70){if(velocityY<70)velocityY+=70;setMode('thrown');}else setMode('land');
 }
 pet.addEventListener('pointerup',release);pet.addEventListener('pointercancel',release);pet.addEventListener('lostpointercapture',release);
 buttons.forEach(b=>b.addEventListener('click',()=>{held=false;pet.classList.remove('dragging');let key=b.dataset.action;
  if(key==='thrown'){y=Math.max(y,130);velocityX=(face>0?1:-1)*180;velocityY=160;}
  if(key==='land')y=15;setMode(key);if(key==='curl'||key==='stretch')auto.checked=true;
 }));
 document.getElementById('reset').addEventListener('click',()=>{held=false;x=stage.clientWidth/2-pet.offsetWidth/2;y=15;velocityX=velocityY=0;setMode('idle');});
 window.addEventListener('resize',()=>{x=clamp(x,0,Math.max(0,stage.clientWidth-pet.offsetWidth));render();});
 setMode('idle');
})();
